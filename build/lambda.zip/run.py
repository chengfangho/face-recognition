from rekognition.main import lambda_handler
