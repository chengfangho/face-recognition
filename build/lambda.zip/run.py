from recognition.main import lambda_handler as recognition_lambda
from registration.main import lambda_handler as registration_lambda
